import { db } from '@/lib/db'; import { requireAdmin } from '@/lib/admin'; import { NextResponse } from 'next/server';
export async function POST(req:Request){
 await requireAdmin();
 const f=await req.formData(); const item=await db.inventory.create({data:{title:String(f.get('title')),slug:String(f.get('slug')),category:String(f.get('category')),description:String(f.get('description')),priceCents:Math.round(Number(f.get('price'))*100),location:String(f.get('location')),specs:JSON.parse(String(f.get('specs')||'{}')),images:[]}});
 return NextResponse.redirect(new URL('/admin',req.url));
}