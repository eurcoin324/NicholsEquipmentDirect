import { NextResponse } from 'next/server';
import { createHmac } from 'crypto';

export async function POST(req:Request){
 const f=await req.formData(); const email=String(f.get('email')); const password=String(f.get('password'));
 const expectedEmail=process.env.ADMIN_EMAIL||''; const expectedHash=process.env.ADMIN_PASSWORD_HASH||'';
 // Starter verification contract: ADMIN_PASSWORD_HASH must be a SHA-256 hex digest of the password.
 const hash=createHmac('sha256', process.env.ADMIN_COOKIE_SECRET||'dev-secret').update(password).digest('hex');
 if(email!==expectedEmail || hash!==expectedHash) return NextResponse.redirect(new URL('/admin/login?error=1',req.url),303);
 const token=createHmac('sha256', process.env.ADMIN_COOKIE_SECRET||'dev-secret').update(email).digest('hex');
 const res=NextResponse.redirect(new URL('/admin',req.url),303);
 res.cookies.set('admin_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:60*60*8});
 return res;
}