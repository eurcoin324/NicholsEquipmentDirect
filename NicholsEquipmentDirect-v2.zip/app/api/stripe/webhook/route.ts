import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { db } from '@/lib/db';

export async function POST(req:Request){
 const stripe=new Stripe(process.env.STRIPE_SECRET_KEY!);
 const sig=req.headers.get('stripe-signature'); const body=await req.text();
 if(!sig) return new NextResponse('Missing signature',{status:400});
 let event:Stripe.Event;
 try{event=stripe.webhooks.constructEvent(body,sig,process.env.STRIPE_WEBHOOK_SECRET!)}
 catch{return new NextResponse('Invalid signature',{status:400})}
 if(event.type==='checkout.session.completed'){
   const session=event.data.object as Stripe.Checkout.Session;
   const orderId=session.metadata?.orderId;
   if(orderId) await db.order.update({where:{id:orderId},data:{status:'PAID'}});
 }
 return NextResponse.json({received:true});
}